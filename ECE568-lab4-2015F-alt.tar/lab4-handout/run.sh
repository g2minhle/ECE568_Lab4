#!/bin/sh

python ece568app.py localhost 12081 INSERT_YOUR_CLIENT_ID_HERE
